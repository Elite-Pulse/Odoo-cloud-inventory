# -*- coding: utf-8 -*-
{
    'name': 'Cloud Inventory',
    'version': '18.0.1.0.0',
    'category': 'Inventory/Cloud',
    'summary': 'Cloud datacenter inventory: servers, licenses, logical assets, racks, reporting',
    'description': """
Cloud Inventory
===============
Standalone inventory for the Cloud department (independent from the ERP stock module).

* Datacenter > Hall > Room > Rack > RU location hierarchy
* Physical, digital (licenses, activation keys) and logical assets
* Stock entry / exit dates, responsible, comments, chatter
* Global dashboard
* Advanced search and filters
* Excel and PDF reporting on any selection
* Configurable lists (brands, models, CPU, RAM, storage, clusters, sites, tags, types)
    """,
    'author': 'Cloud Team',
    'depends': ['base', 'mail'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'data/seed_data.xml',
        'views/location_views.xml',
        'views/config_views.xml',
        'views/asset_views.xml',
        'views/dashboard_views.xml',
        'report/report_assets.xml',
        'wizard/report_wizard_views.xml',
        'views/menus.xml',
    ],
    'application': True,
    'installable': True,
    'license': 'LGPL-3',
}
