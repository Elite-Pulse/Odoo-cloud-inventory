# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import ValidationError


class CloudInvConfigMixin(models.AbstractModel):
    """Base for every configurable list (Settings > Variables)."""
    _name = 'cloud.inv.config.mixin'
    _description = 'Cloud Inventory configurable list'
    _order = 'sequence, name'

    name = fields.Char(required=True)
    sequence = fields.Integer(default=10)
    active = fields.Boolean(default=True)

    @api.constrains('name')
    def _check_unique_name(self):
        for rec in self:
            dup = self.with_context(active_test=False).search_count(
                [('name', '=ilike', rec.name), ('id', '!=', rec.id)])
            if dup:
                raise ValidationError(_('"%s" already exists in this list.') % rec.name)


class CloudInvBrand(models.Model):
    _name = 'cloud.inv.brand'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Marque'
    name = fields.Char('Marque', required=True)


class CloudInvModel(models.Model):
    _name = 'cloud.inv.model'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Modèle'
    name = fields.Char('Modèle', required=True)
    brand_id = fields.Many2one('cloud.inv.brand', 'Marque')

    @api.constrains('name')
    def _check_unique_name(self):
        for rec in self:
            dup = self.with_context(active_test=False).search_count(
                [('name', '=ilike', rec.name), ('brand_id', '=', rec.brand_id.id), ('id', '!=', rec.id)])
            if dup:
                raise ValidationError(_('Model "%s" already exists for this brand.') % rec.name)


class CloudInvCpu(models.Model):
    _name = 'cloud.inv.cpu'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'CPU'
    name = fields.Char('CPU', required=True)


class CloudInvRam(models.Model):
    _name = 'cloud.inv.ram'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'RAM'
    name = fields.Char('RAM', required=True)


class CloudInvStorage(models.Model):
    _name = 'cloud.inv.storage'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Storage'
    name = fields.Char('Storage', required=True)


class CloudInvCluster(models.Model):
    _name = 'cloud.inv.cluster'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Cluster'
    name = fields.Char('Cluster', required=True)


class CloudInvSite(models.Model):
    _name = 'cloud.inv.site'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Site'
    name = fields.Char('Site', required=True)


class CloudInvTag(models.Model):
    _name = 'cloud.inv.tag'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'TAG (plateforme)'
    name = fields.Char('TAG', required=True)


class CloudInvProductType(models.Model):
    _name = 'cloud.inv.product.type'
    _inherit = 'cloud.inv.config.mixin'
    _description = 'Type de produit'
    name = fields.Char('Type de produit', required=True)
    nature = fields.Selection([
        ('physical', 'Physique'), ('digital', 'Digital'), ('logical', 'Logique')],
        string='Nature par défaut', default='physical')
