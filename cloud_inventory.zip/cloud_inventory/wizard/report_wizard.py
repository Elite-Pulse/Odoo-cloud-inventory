# -*- coding: utf-8 -*-
import base64
import io

from odoo import _, fields, models
from odoo.exceptions import UserError
from odoo.osv import expression


class CloudInvReportWizard(models.TransientModel):
    _name = 'cloud.inv.report.wizard'
    _description = 'Cloud Inventory Export (Excel / PDF)'

    # Selection coming from a list view (optional)
    asset_ids = fields.Many2many('cloud.inv.asset', 'cloud_inv_rw_asset_rel', 'wiz_id', 'asset_id', string='Sélection')

    # Filters
    datacenter_ids = fields.Many2many('cloud.inv.datacenter', 'cloud_inv_rw_dc_rel', 'wiz_id', 'rec_id', string='Datacenters')
    hall_ids = fields.Many2many('cloud.inv.hall', 'cloud_inv_rw_hall_rel', 'wiz_id', 'rec_id', string='Halls')
    room_ids = fields.Many2many('cloud.inv.room', 'cloud_inv_rw_room_rel', 'wiz_id', 'rec_id', string='Rooms')
    rack_ids = fields.Many2many('cloud.inv.rack', 'cloud_inv_rw_rack_rel', 'wiz_id', 'rec_id', string='Racks')
    product_type_ids = fields.Many2many('cloud.inv.product.type', 'cloud_inv_rw_type_rel', 'wiz_id', 'rec_id', string='Types de produit')
    brand_ids = fields.Many2many('cloud.inv.brand', 'cloud_inv_rw_brand_rel', 'wiz_id', 'rec_id', string='Marques')
    model_ids = fields.Many2many('cloud.inv.model', 'cloud_inv_rw_model_rel', 'wiz_id', 'rec_id', string='Modèles')
    cluster_ids = fields.Many2many('cloud.inv.cluster', 'cloud_inv_rw_cluster_rel', 'wiz_id', 'rec_id', string='Clusters')
    cpu_ids = fields.Many2many('cloud.inv.cpu', 'cloud_inv_rw_cpu_rel', 'wiz_id', 'rec_id', string='CPU')
    ram_ids = fields.Many2many('cloud.inv.ram', 'cloud_inv_rw_ram_rel', 'wiz_id', 'rec_id', string='RAM')
    storage_ids = fields.Many2many('cloud.inv.storage', 'cloud_inv_rw_storage_rel', 'wiz_id', 'rec_id', string='Storage')
    tag_ids = fields.Many2many('cloud.inv.tag', 'cloud_inv_rw_tag_rel', 'wiz_id', 'rec_id', string='TAG')
    site_ids = fields.Many2many('cloud.inv.site', 'cloud_inv_rw_site_rel', 'wiz_id', 'rec_id', string='Sites')
    responsible_ids = fields.Many2many('res.users', 'cloud_inv_rw_user_rel', 'wiz_id', 'user_id', string='Responsables')
    nature = fields.Selection([('physical', 'Physique'), ('digital', 'Digital'), ('logical', 'Logique')], string='Nature')
    state = fields.Selection([('in_stock', 'En stock'), ('out', 'Sorti du stock')], string='État')
    date_in_from = fields.Date("Entrée en stock du")
    date_in_to = fields.Date('au')
    date_out_from = fields.Date('Sortie du stock du')
    date_out_to = fields.Date('au ')
    search_text = fields.Char('Recherche libre', help='Nom, référence, Service Tag, commentaire')

    file_data = fields.Binary('Fichier', readonly=True)
    file_name = fields.Char('Nom du fichier')

    # ---------- selection ----------
    def _get_domain(self):
        self.ensure_one()
        if self.asset_ids:
            return [('id', 'in', self.asset_ids.ids)]
        d = []
        m2m = [
            ('datacenter_ids', 'datacenter_id'), ('hall_ids', 'hall_id'), ('room_ids', 'room_id'),
            ('rack_ids', 'rack_id'), ('product_type_ids', 'product_type_id'), ('brand_ids', 'brand_id'),
            ('model_ids', 'model_id'), ('cluster_ids', 'cluster_id'), ('cpu_ids', 'cpu_id'),
            ('ram_ids', 'ram_id'), ('storage_ids', 'storage_id'), ('tag_ids', 'tag_id'),
            ('site_ids', 'site_id'), ('responsible_ids', 'responsible_id'),
        ]
        for wf, af in m2m:
            if self[wf]:
                d.append((af, 'in', self[wf].ids))
        if self.nature:
            d.append(('nature', '=', self.nature))
        if self.state:
            d.append(('state', '=', self.state))
        if self.date_in_from:
            d.append(('date_in', '>=', self.date_in_from))
        if self.date_in_to:
            d.append(('date_in', '<=', self.date_in_to))
        if self.date_out_from:
            d.append(('date_out', '>=', self.date_out_from))
        if self.date_out_to:
            d.append(('date_out', '<=', self.date_out_to))
        if self.search_text:
            t = self.search_text
            d = expression.AND([d, expression.OR([
                [('name', 'ilike', t)], [('reference', 'ilike', t)],
                [('service_tag', 'ilike', t)], [('comment', 'ilike', t)]])])
        return d

    def get_assets(self):
        self.ensure_one()
        return self.env['cloud.inv.asset'].search(self._get_domain(), order='datacenter_id, rack_id, ru_start, name')

    def get_filters_summary(self):
        self.ensure_one()
        if self.asset_ids:
            return _('Sélection manuelle de %s élément(s)') % len(self.asset_ids)
        parts = []
        for f in ['datacenter_ids', 'hall_ids', 'room_ids', 'rack_ids', 'product_type_ids', 'brand_ids',
                  'model_ids', 'cluster_ids', 'cpu_ids', 'ram_ids', 'storage_ids', 'tag_ids', 'site_ids',
                  'responsible_ids']:
            if self[f]:
                parts.append('%s: %s' % (self._fields[f].string, ', '.join(self[f].mapped('display_name'))))
        if self.nature:
            parts.append('Nature: %s' % dict(self._fields['nature'].selection)[self.nature])
        if self.state:
            parts.append('État: %s' % dict(self._fields['state'].selection)[self.state])
        if self.date_in_from or self.date_in_to:
            parts.append('Entrée: %s → %s' % (self.date_in_from or '…', self.date_in_to or '…'))
        if self.date_out_from or self.date_out_to:
            parts.append('Sortie: %s → %s' % (self.date_out_from or '…', self.date_out_to or '…'))
        if self.search_text:
            parts.append('Texte: %s' % self.search_text)
        return ' | '.join(parts) or _('Aucun filtre (tout le stock)')

    # ---------- exports ----------
    def action_print_pdf(self):
        self.ensure_one()
        if not self.get_assets():
            raise UserError(_('Aucun résultat pour ces filtres.'))
        return self.env.ref('cloud_inventory.action_report_assets').report_action(self)

    def _row(self, a):
        nat = dict(a._fields['nature'].selection).get(a.nature, '')
        st = dict(a._fields['state'].selection).get(a.state, '')
        return [
            a.reference, nat, a.product_type_id.name, a.brand_id.name, a.model_id.name, a.name,
            a.cluster_id.name, a.cpu_id.name, a.ram_id.name, a.storage_id.name, a.service_tag,
            a.tag_id.name, a.datacenter_id.name, a.hall_id.name, a.room_id.name, a.rack_id.name,
            a.ru_display, a.site_id.name,
            a.date_in and a.date_in.strftime('%d/%m/%Y') or '',
            a.date_out and a.date_out.strftime('%d/%m/%Y') or '',
            st, a.responsible_id.name, a.license_expiry and a.license_expiry.strftime('%d/%m/%Y') or '',
            a.comment,
        ]

    HEADERS = ['Référence', 'Nature', 'Type', 'Marque', 'Modèle', 'Nom', 'Cluster', 'CPU', 'RAM', 'Storage',
               'Service Tag', 'TAG', 'Datacenter', 'Hall', 'Room', 'Rack', 'RU', 'Site',
               "Date d'entrée", 'Date de sortie', 'État', 'Responsable', 'Expiration licence', 'Commentaire']

    def action_export_xlsx(self):
        self.ensure_one()
        try:
            import xlsxwriter
        except ImportError:
            raise UserError(_('Python package xlsxwriter is required.'))
        assets = self.get_assets()
        if not assets:
            raise UserError(_('Aucun résultat pour ces filtres.'))
        buf = io.BytesIO()
        wb = xlsxwriter.Workbook(buf, {'in_memory': True})
        ws = wb.add_worksheet('Inventaire Cloud')
        title = wb.add_format({'bold': True, 'font_size': 16, 'font_color': '#714B67'})
        sub = wb.add_format({'italic': True, 'font_color': '#555555'})
        head = wb.add_format({'bold': True, 'bg_color': '#714B67', 'font_color': '#FFFFFF',
                              'border': 1, 'align': 'center', 'valign': 'vcenter', 'text_wrap': True})
        cell = wb.add_format({'border': 1, 'valign': 'top'})
        cell_alt = wb.add_format({'border': 1, 'valign': 'top', 'bg_color': '#F4EFF3'})
        ws.write(0, 0, 'Inventaire Cloud', title)
        ws.write(1, 0, 'Généré le %s par %s — %s élément(s)' % (
            fields.Datetime.context_timestamp(self, fields.Datetime.now()).strftime('%d/%m/%Y %H:%M'),
            self.env.user.name, len(assets)), sub)
        ws.write(2, 0, 'Filtres: %s' % self.get_filters_summary(), sub)
        hr = 4
        ws.set_row(hr, 28)
        for c, h in enumerate(self.HEADERS):
            ws.write(hr, c, h, head)
        widths = [14, 11, 16, 12, 16, 28, 20, 30, 9, 11, 16, 11, 20, 12, 12, 10, 7, 8, 13, 13, 13, 18, 14, 40]
        for c, w in enumerate(widths):
            ws.set_column(c, c, w)
        for i, a in enumerate(assets):
            fmt = cell_alt if i % 2 else cell
            for c, v in enumerate(self._row(a)):
                ws.write(hr + 1 + i, c, v or '', fmt)
        ws.autofilter(hr, 0, hr + len(assets), len(self.HEADERS) - 1)
        ws.freeze_panes(hr + 1, 0)

        # Summary sheet
        ws2 = wb.add_worksheet('Résumé')
        ws2.set_column(0, 0, 28)
        ws2.set_column(1, 1, 12)
        ws2.write(0, 0, 'Résumé', title)
        r = 2
        for label, getter in [('Par Datacenter', lambda a: a.datacenter_id.name),
                              ('Par Type', lambda a: a.product_type_id.name),
                              ('Par Marque', lambda a: a.brand_id.name),
                              ('Par État', lambda a: dict(a._fields['state'].selection)[a.state])]:
            ws2.write(r, 0, label, head)
            ws2.write(r, 1, 'Nombre', head)
            r += 1
            counts = {}
            for a in assets:
                k = getter(a) or 'Non défini'
                counts[k] = counts.get(k, 0) + 1
            for k, v in sorted(counts.items(), key=lambda x: -x[1]):
                ws2.write(r, 0, k, cell)
                ws2.write(r, 1, v, cell)
                r += 1
            r += 1
        wb.close()
        self.write({
            'file_data': base64.b64encode(buf.getvalue()),
            'file_name': 'inventaire_cloud_%s.xlsx' % fields.Date.context_today(self).strftime('%Y%m%d'),
        })
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/?model=%s&id=%s&field=file_data&filename_field=file_name&download=true' % (
                self._name, self.id),
            'target': 'self',
        }

    def action_reset(self):
        self.ensure_one()
        self.write({f: [(5, 0, 0)] for f in self._fields
                    if self._fields[f].type == 'many2many'})
        self.write({'nature': False, 'state': False, 'date_in_from': False, 'date_in_to': False,
                    'date_out_from': False, 'date_out_to': False, 'search_text': False})
        return {'type': 'ir.actions.act_window', 'res_model': self._name, 'res_id': self.id,
                'view_mode': 'form', 'target': 'new'}
