# -*- coding: utf-8 -*-
from datetime import timedelta

from markupsafe import Markup, escape

from odoo import _, fields, models


class CloudInvDashboard(models.Model):
    _name = 'cloud.inv.dashboard'
    _description = 'Cloud Inventory Dashboard'

    total = fields.Integer(string='Total Products', compute='_compute_kpis')
    in_stock = fields.Integer(string='In Stock', compute='_compute_kpis')
    out_stock = fields.Integer(string='Out of Stock', compute='_compute_kpis')
    physical = fields.Integer(string='Physical', compute='_compute_kpis')
    digital = fields.Integer(string='Digital', compute='_compute_kpis')
    logical = fields.Integer(string='Logical', compute='_compute_kpis')
    expiring = fields.Integer(string='Expiring Soon', compute='_compute_kpis')
    expired = fields.Integer(string='Expired', compute='_compute_kpis')
    html_datacenter = fields.Html(string='By Datacenter', compute='_compute_tables', sanitize=False)
    html_type = fields.Html(string='By Product Type', compute='_compute_tables', sanitize=False)
    html_brand = fields.Html(string='By Brand', compute='_compute_tables', sanitize=False)
    html_racks = fields.Html(string='Rack Usage', compute='_compute_tables', sanitize=False)

    # ---------- helpers ----------
    def _expiring_domain(self):
        today = fields.Date.context_today(self)
        return [('nature', '=', 'digital'), ('state', '=', 'in_stock'),
                ('license_expiry', '>=', today), ('license_expiry', '<=', today + timedelta(days=30))]

    def _expired_domain(self):
        return [('nature', '=', 'digital'), ('state', '=', 'in_stock'),
                ('license_expiry', '<', fields.Date.context_today(self))]

    def _compute_kpis(self):
        A = self.env['cloud.inv.asset']
        for rec in self:
            rec.total = A.search_count([])
            rec.in_stock = A.search_count([('state', '=', 'in_stock')])
            rec.out_stock = A.search_count([('state', '=', 'out')])
            rec.physical = A.search_count([('nature', '=', 'physical')])
            rec.digital = A.search_count([('nature', '=', 'digital')])
            rec.logical = A.search_count([('nature', '=', 'logical')])
            rec.expiring = A.search_count(self._expiring_domain())
            rec.expired = A.search_count(self._expired_domain())

    def _bar_table(self, title, rows, color):
        """rows: list of (label, count)."""
        top = max([c for _l, c in rows] or [1]) or 1
        body = Markup('')
        for label, count in rows:
            pct = int(count * 100 / top)
            body += Markup(
                '<tr><td style="padding:4px 10px 4px 0;white-space:nowrap">%s</td>'
                '<td style="width:100%%"><div style="background:#eef0f4;border-radius:6px;height:14px">'
                '<div style="width:%s%%;background:%s;height:14px;border-radius:6px"></div></div></td>'
                '<td style="padding-left:10px;text-align:right"><b>%s</b></td></tr>'
            ) % (escape(label), pct, color, count)
        if not rows:
            body = Markup('<tr><td class="text-muted">%s</td></tr>') % _('No data')
        return Markup('<h5 style="margin:0 0 8px">%s</h5><table style="width:100%%">%s</table>') % (title, body)

    def _group_rows(self, field):
        res = self.env['cloud.inv.asset'].read_group([], [field], [field])
        rows = []
        for r in res:
            val = r[field]
            label = val[1] if val else _('Undefined')
            rows.append((label, r.get('__count', r.get(field + '_count', 0))))
        rows.sort(key=lambda x: -x[1])
        return rows

    def _compute_tables(self):
        for rec in self:
            rec.html_datacenter = rec._bar_table(_('By Datacenter'), rec._group_rows('datacenter_id'), '#714B67')
            rec.html_type = rec._bar_table(_('By Product Type'), rec._group_rows('product_type_id'), '#017E84')
            rec.html_brand = rec._bar_table(_('By Brand'), rec._group_rows('brand_id')[:10], '#F06050')
            racks = self.env['cloud.inv.rack'].search([])
            racks = sorted(racks, key=lambda r: -r.usage_percent)[:10]
            rows = [('%s (%s/%s RU)' % (r.complete_name, r.used_ru, r.total_ru), int(r.usage_percent))
                    for r in racks]
            rec.html_racks = rec._bar_table(_('Rack Usage (%)'), rows, '#F4A460')

    # ---------- actions ----------
    def _open_assets(self, name, domain):
        return {
            'type': 'ir.actions.act_window', 'name': name, 'res_model': 'cloud.inv.asset',
            'view_mode': 'list,kanban,form,pivot,graph', 'domain': domain,
        }

    def action_total(self):
        return self._open_assets(_('All Products'), [])

    def action_in_stock(self):
        return self._open_assets(_('In Stock'), [('state', '=', 'in_stock')])

    def action_out_stock(self):
        return self._open_assets(_('Out of Stock'), [('state', '=', 'out')])

    def action_physical(self):
        return self._open_assets(_('Physical'), [('nature', '=', 'physical')])

    def action_digital(self):
        return self._open_assets(_('Digital'), [('nature', '=', 'digital')])

    def action_logical(self):
        return self._open_assets(_('Logical'), [('nature', '=', 'logical')])

    def action_expiring(self):
        return self._open_assets(_('Licenses expiring within 30 days'), self._expiring_domain())

    def action_expired(self):
        return self._open_assets(_('Expired licenses'), self._expired_domain())
