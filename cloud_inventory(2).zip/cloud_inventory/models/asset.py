# -*- coding: utf-8 -*-
from odoo import _, api, fields, models
from odoo.exceptions import AccessError, UserError, ValidationError

MANAGER_GROUP = 'cloud_inventory.group_cloud_inv_manager'


class CloudInvAsset(models.Model):
    _name = 'cloud.inv.asset'
    _description = 'Cloud Inventory Asset'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_in desc, id desc'

    name = fields.Char(string='Name', required=True, tracking=True)
    reference = fields.Char(string='Reference', readonly=True, copy=False, default='/')
    nature = fields.Selection([
        ('physical', 'Physical'),
        ('digital', 'Digital (license / key)'),
        ('logical', 'Logical'),
    ], string='Nature', required=True, default='physical', tracking=True)
    product_type_id = fields.Many2one('cloud.inv.product.type', string='Product Type', tracking=True)

    brand_id = fields.Many2one('cloud.inv.brand', string='Brand', tracking=True)
    model_id = fields.Many2one('cloud.inv.model', string='Model',
                               domain="[('brand_id', 'in', (brand_id, False))]", tracking=True)
    cluster_id = fields.Many2one('cloud.inv.cluster', string='Cluster', tracking=True)
    cpu_id = fields.Many2one('cloud.inv.cpu', string='CPU')
    ram_id = fields.Many2one('cloud.inv.ram', string='RAM')
    storage_id = fields.Many2one('cloud.inv.storage', string='Storage')
    service_tag = fields.Char(string='Service Tag', tracking=True)
    tag_id = fields.Many2one('cloud.inv.tag', string='TAG', tracking=True)
    site_id = fields.Many2one('cloud.inv.site', string='Site')

    # Location (applies to every nature: physical, digital and logical)
    datacenter_id = fields.Many2one('cloud.inv.datacenter', string='Datacenter', tracking=True)
    hall_id = fields.Many2one('cloud.inv.hall', string='Hall',
                              domain="[('datacenter_id', '=', datacenter_id)]", tracking=True)
    room_id = fields.Many2one('cloud.inv.room', string='Room',
                              domain="[('hall_id', '=', hall_id)]", tracking=True)
    rack_id = fields.Many2one('cloud.inv.rack', string='Rack',
                              domain="[('room_id', '=', room_id)]", tracking=True)
    ru_start = fields.Integer(string='RU Start')
    ru_end = fields.Integer(string='RU End')
    ru_display = fields.Char(string='RU', compute='_compute_ru_display', store=True)

    # Digital
    license_key = fields.Char(string='License / Key', groups='cloud_inventory.group_cloud_inv_user')
    license_expiry = fields.Date(string='Expiry Date', tracking=True)
    license_seats = fields.Integer(string='Seats / Cores')

    # Stock management
    state = fields.Selection([
        ('in_stock', 'In Stock'), ('out', 'Out of Stock')],
        string='Status', default='in_stock', required=True, tracking=True)
    date_in = fields.Date(string='Stock Entry Date', default=fields.Date.context_today, tracking=True)
    date_out = fields.Date(string='Stock Exit Date', tracking=True)
    responsible_id = fields.Many2one('res.users', string='Responsible',
                                     default=lambda s: s.env.user, tracking=True)
    comment = fields.Text(string='Comment')

    @api.depends('ru_start', 'ru_end')
    def _compute_ru_display(self):
        for rec in self:
            if rec.ru_start and rec.ru_end and rec.ru_end != rec.ru_start:
                rec.ru_display = '%s-%s' % (rec.ru_start, rec.ru_end)
            elif rec.ru_start:
                rec.ru_display = str(rec.ru_start)
            else:
                rec.ru_display = False

    # ---- location cascade ----
    @api.onchange('rack_id')
    def _onchange_rack(self):
        if self.rack_id:
            self.room_id = self.rack_id.room_id
            self.hall_id = self.rack_id.hall_id
            self.datacenter_id = self.rack_id.datacenter_id

    @api.onchange('room_id')
    def _onchange_room(self):
        if self.room_id:
            self.hall_id = self.room_id.hall_id
            self.datacenter_id = self.room_id.datacenter_id
        if self.rack_id and self.rack_id.room_id != self.room_id:
            self.rack_id = False

    @api.onchange('hall_id')
    def _onchange_hall(self):
        if self.hall_id:
            self.datacenter_id = self.hall_id.datacenter_id
        if self.room_id and self.room_id.hall_id != self.hall_id:
            self.room_id = False
            self.rack_id = False

    @api.onchange('datacenter_id')
    def _onchange_datacenter(self):
        if self.hall_id and self.hall_id.datacenter_id != self.datacenter_id:
            self.hall_id = False
            self.room_id = False
            self.rack_id = False

    @api.onchange('brand_id')
    def _onchange_brand(self):
        if self.model_id and self.model_id.brand_id and self.model_id.brand_id != self.brand_id:
            self.model_id = False

    @api.onchange('model_id')
    def _onchange_model(self):
        if self.model_id.brand_id:
            self.brand_id = self.model_id.brand_id

    @api.onchange('product_type_id')
    def _onchange_product_type(self):
        if self.product_type_id.nature:
            self.nature = self.product_type_id.nature

    # ---- constraints ----
    @api.constrains('rack_id', 'room_id', 'hall_id', 'datacenter_id')
    def _check_location_consistency(self):
        for rec in self:
            if rec.rack_id and rec.room_id and rec.rack_id.room_id != rec.room_id:
                raise ValidationError(_('The rack does not belong to the selected room.'))
            if rec.room_id and rec.hall_id and rec.room_id.hall_id != rec.hall_id:
                raise ValidationError(_('The room does not belong to the selected hall.'))
            if rec.hall_id and rec.datacenter_id and rec.hall_id.datacenter_id != rec.datacenter_id:
                raise ValidationError(_('The hall does not belong to the selected datacenter.'))

    @api.constrains('rack_id', 'ru_start', 'ru_end', 'state')
    def _check_rack_units(self):
        for rec in self:
            if not rec.rack_id or not rec.ru_start:
                continue
            start, end = rec.ru_start, (rec.ru_end or rec.ru_start)
            if start < 1 or end < start or (rec.rack_id.total_ru and end > rec.rack_id.total_ru):
                raise ValidationError(_('Invalid RU range %s-%s for rack %s (%s RU).') % (
                    start, end, rec.rack_id.name, rec.rack_id.total_ru))
            if rec.state == 'out':
                continue
            clash = self.search([
                ('id', '!=', rec.id), ('rack_id', '=', rec.rack_id.id), ('state', '=', 'in_stock'),
                ('ru_start', '>', 0), ('ru_start', '<=', end)]).filtered(
                lambda a: (a.ru_end or a.ru_start) >= start)
            if clash:
                raise ValidationError(_('RU %s-%s in rack %s already used by: %s') % (
                    start, end, rec.rack_id.name, ', '.join(clash.mapped('name'))))

    @api.constrains('date_in', 'date_out')
    def _check_dates(self):
        for rec in self:
            if rec.date_in and rec.date_out and rec.date_out < rec.date_in:
                raise ValidationError(_('The exit date cannot be before the entry date.'))

    # ---- CRUD ----
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('reference') or vals.get('reference') == '/':
                vals['reference'] = self.env['ir.sequence'].next_by_code('cloud.inv.asset') or '/'
        return super().create(vals_list)

    @api.depends('name', 'reference')
    def _compute_display_name(self):
        for r in self:
            if r.reference and r.reference != '/':
                r.display_name = '[%s] %s' % (r.reference, r.name or '')
            else:
                r.display_name = r.name or ''

    # ---- stock actions ----
    def action_out(self):
        self.write({'state': 'out', 'date_out': fields.Date.context_today(self)})

    def action_in(self):
        self.write({'state': 'in_stock', 'date_out': False})

    # ---- export (managers and administrators only) ----
    def _check_export_rights(self):
        if not self.env.user.has_group(MANAGER_GROUP):
            raise AccessError(_('Only Cloud Inventory managers and administrators can export data.'))

    def _selection_wizard(self):
        self._check_export_rights()
        return self.env['cloud.inv.report.wizard'].create({'asset_ids': [(6, 0, self.ids)]})

    def action_export_selected(self):
        """Bound to the list view: open the export wizard on the selection."""
        self._check_export_rights()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Export selection'),
            'res_model': 'cloud.inv.report.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_asset_ids': [(6, 0, self.ids)]},
        }

    def action_export_xlsx_selected(self):
        return self._selection_wizard().action_export_xlsx()

    def action_print_pdf_selected(self):
        return self._selection_wizard().action_print_pdf()

    # ---- language switch (FR / EN) ----
    @api.model
    def action_switch_lang(self, code):
        lang = self.env['res.lang'].search([('code', '=', code)], limit=1)
        if not lang:
            raise UserError(_(
                'The language %s is not active. Ask an administrator to activate it '
                'in Settings > Translations > Languages.') % code)
        self.env.user.sudo().write({'lang': code})
        return {'type': 'ir.actions.client', 'tag': 'reload_context'}
